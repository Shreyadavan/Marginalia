# Lecture 5: Introduction to the Derivative

Today we study how fast things change. Suppose a car's position is given by a function f(x) of time. Its average speed between two moments is the rise over run of the graph between those points. Of course, an average hides what happens at a single instant, and that is exactly what the derivative captures.

## Instantaneous rate of change

Pick a point on the curve and a second point nearby, and draw the line through both. As the second point approaches the first, this line settles toward the tangent line at that point. Intuitively, we zoom in until the curve looks straight. Clearly, the slope of that final line is the quantity we want.

## The formal definition

We define the derivative as f'(a) = lim (h -> 0) [f(a+h) - f(a)] / h, provided the limit exists. Hence the derivative is the slope of the tangent line, and it is easy to see that it measures instantaneous rate of change. To make "exists" precise one uses epsilon and delta: for every epsilon > 0 there is a delta > 0 such that the quotient stays within epsilon of the limit whenever |h| < delta.

## Notation

Leibniz wrote the derivative of y with respect to x as dy/dx. Both f'(x) and dy/dx mean the same thing, and we will switch between them freely.

## Computing derivatives

The power rule states that the derivative of x^n is n x^(n-1). Therefore the derivative of x^5 is 5x^4. It turns out that most polynomials can be differentiated term by term using this rule.

## Composite functions

For a function inside another function we use the chain rule. Plug in the inner function, differentiate the outer one, and multiply by the derivative of the inner one. It follows that d/dx (x^2 + 1)^3 = 3(x^2 + 1)^2 * 2x.
