"""One-command demo that explains itself:  python demo.py [file] [--mode critic|plain]"""
import argparse
from pathlib import Path

from marginalia import editor, llm, loader, pipeline, report, scoring


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", nargs="?", default="data/sample_lecture.md")
    ap.add_argument("--mode", choices=["plain", "critic"], default="critic")
    a = ap.parse_args()
    text = loader.load_path(a.file)
    bar = "=" * 70
    print(bar + "\nMARGINALIA: a proofreader that reads your notes like a confused student\n" + bar)
    if llm.MOCK:
        print("(Offline demo mode: a keyword heuristic plays the student. Add an API key for real LLM students.)")
    print("\nSTEP 1  Reading your material and splitting it into paragraphs...")
    an = pipeline.run(text, mode=a.mode)
    print(f"        {len(an.chunks)} paragraphs found.")
    print("\nSTEP 2  Working out which topics depend on which (the 'prerequisite map'):")
    for node, data in sorted(an.graph.nodes(data=True), key=lambda x: x[1].get("depth", 0)):
        pre = sorted(an.graph.predecessors(node))
        print(f"        {node.replace('_', ' '):18s} needs: {', '.join(p.replace('_', ' ') for p in pre) or '(nothing, it is basic)'}")
    print("\nSTEP 3  Pretending to be different students (each knows only part of the map):")
    for p in an.personas:
        print(f"        - {p['plain']}: {p['desc']}")
    print("\nSTEP 4  Each student reads every paragraph and 'thinks aloud'. Example:")
    ex = max((t for t in an.traces if t.persona_id == "prereq_gap"), key=scoring.confusion_score)
    print(f"        Student missing the basics, paragraph {ex.chunk_id}:\n        \"{ex.think_aloud}\"")
    print("\nSTEP 5  RESULT: confusion map (0 = clear, 10 = very confusing)\n")
    heat = scoring.heat_matrix(an.df)
    heat.index = [report.plain_name(an, i) for i in heat.index]
    heat.columns = [f"P{c}" for c in heat.columns]
    print(heat.round(1).to_string())
    print("\n" + report.summary_text(an))
    print("\nWHAT TO CHANGE")
    for f in report.findings(an):
        if f["level"] != "Easy":
            print(f"  Paragraph {f['chunk']} ({f['title']}), {f['level']} {f['score']}/10, hard for: {', '.join(f['who'])}")
            for adv in f["advice"]:
                print(f"     * {adv}")
    print("\nSTEP 6  Testing a fix: add the missing definitions, then re-run the students...")
    edits = editor.improve(an, top_n=3)
    for r in edits:
        print(f"        Paragraph {r['chunk']}: confusion {r['before']} -> {r['after']} (improved by {r['gain']})")
    if not edits:
        print("        Nothing was hard enough to need a fix.")
    out = Path("results"); out.mkdir(exist_ok=True)
    (out / "report.html").write_text(report.html_report(an, edits), encoding="utf-8")
    print(f"\nA shareable report was saved to {out / 'report.html'} (open it in a browser).")


if __name__ == "__main__":
    main()
