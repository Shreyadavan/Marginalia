# Marginalia explained simply

## 1. The project in one minute

**Problem.** A teacher writes lecture notes. Because the teacher already knows the subject, the notes skip steps
and use words students have never seen (this is called the *curse of knowledge*). The teacher usually finds out
only after students fail an exam or flood the forum with questions.

**Idea.** What if a program could read the notes as a *confused student* and say, before the course starts,
"paragraph 3 will lose people who haven't learned limits"?

**Analogy.** It is like **beta-testing a game with test players before launch**, but the test players are
AI-simulated students and the game is your lecture notes.

**What we built.** A tool that
1. reads the notes and builds a map of which topic needs which (limits, then derivative, then chain rule);
2. creates several **simulated students**, each knowing only part of that map;
3. asks an AI model (an LLM) to read each paragraph *as that student* and think aloud;
4. checks the AI is not **cheating** (an AI knows everything, so it may use knowledge it was told it doesn't have);
5. draws a **colour map** (red = confusing) and says in plain English what to change;
6. tries a fix (like adding a definition) and **re-tests** it to see whether confusion drops.

## 2. A tiny worked example

Sentence in the notes: *"Hence the derivative is the slope of the tangent line, and it is easy to see..."*

| Student | What they think aloud | Result |
|---|---|---|
| Well-prepared | "Fine, I know all of this." | Clear |
| Missing the basics | "I get stuck on 'derivative'. The author jumps ahead without showing why." | Red |
| Non-native English | "I don't know the phrase 'zoom in'." | Orange |

Suggested fix: *add one line defining "derivative" and "tangent line".* After the fix we run the students again and
the score drops (in the demo: 4.5 to 1.0).

## 3. The three things that make it a real project (not just a chatbot)

1. **It helps the teacher, not the student.** Most AI-in-education tools are tutors or quiz makers.
2. **Students are defined by what they know, not by who they are.** Each one is a list of mastered / half-known /
   unknown topics taken from the prerequisite map. That avoids stereotypes.
3. **It measures its own weakness.** AI models "cheat" (knowledge leakage). We detect it, retry, and report the rate.

## 4. What is finished and what is not (be honest in your presentation)

- **Finished and tested:** the whole pipeline, the web app, PDF/Word/text input, the report, 11 unit tests.
- **Offline demo mode:** without an API key a simple keyword program plays the student. It shows how the tool works,
  but its numbers are **not research results**.
- **Not done yet:** running with a real AI model on real courses and comparing with real student data
  (forum questions, exam errors). The code for these experiments exists (`evaluate.py`); the data is needed.

## 5. How to run the demo (3 minutes)

```
pip install -r requirements.txt
python demo.py                 # prints the whole story in the terminal and saves results/report.html
streamlit run app.py           # the web app: click "One-click demo"
```
For real AI students: copy `.env.example` to `.env` and add `ANTHROPIC_API_KEY`.

### What to say while presenting
1. (20 s) The problem: teachers forget what it is like not to know; they find out too late.
2. (20 s) The idea: simulated confused students read the notes first.
3. (40 s) Run `demo.py` or click **One-click demo**; point at the colour map: "red = students get lost here".
4. (30 s) Open "Read a student's mind": show one think-aloud. Then show the plain-English advice.
5. (30 s) Show **Fix and re-test**: confusion drops after adding a definition.
6. (20 s) Honesty slide: cheating check, fairness check, and what still needs real data.

## 6. Questions a teacher might ask

**Why use an LLM at all?** Because it can read free text and describe *why* something is confusing in words;
a readability formula (Flesch) only counts sentence length and cannot see a missing prerequisite.

**Isn't the AI too smart to play a confused student?** Yes, that is the main research question. We call it
knowledge leakage, detect it with a checker, make the student retry, and report how often it happens.

**How do you know the confusion is real?** We do not claim it yet. The plan (`evaluate.py correlate`) is to compare
the predicted red paragraphs with real forum questions and exam errors using Spearman rank correlation.

**What is a prerequisite graph?** A map where an arrow A -> B means "learn A before B". Depth tells how
advanced a topic is. Students are defined by how deep their knowledge goes.

**What is the confusion score?** A 0-10 number from: unknown words, missing background, skipped steps,
unstated assumptions and low self-reported confidence, with the weights in `config.py`.

**How is it fair?** Students are defined by knowledge, not nationality or age. A fairness audit checks the
think-alouds for stereotype words and checks that each problem is explained by what the student lacks.

**What is the novelty?** Using LLM-simulated limited-knowledge readers to audit *teaching material* before use,
and measuring leakage and realism instead of assuming them.

**What are the limits?** The AI may under-report confusion; the prerequisite map comes from an LLM and may be
imperfect; text only (no figures); few student types; real-data validation pending.

**Which tools did you use?** Python, an LLM API, NetworkX (graph), Pandas/SciPy (analysis), Streamlit/Plotly (app).

## 7. Where things are in the code

| File | In plain words |
|---|---|
| `marginalia/chunker.py` | splits notes into paragraphs |
| `marginalia/concepts.py` | finds topics and builds the prerequisite map |
| `marginalia/personas.py` | the simulated students |
| `marginalia/reader.py` | the student reading and thinking aloud |
| `marginalia/leakage.py` | catches the AI cheating |
| `marginalia/scoring.py` | turns thinking into a 0-10 score |
| `marginalia/editor.py` | proposes and re-tests a fix |
| `marginalia/report.py` | plain-English findings and the HTML report |
| `marginalia/audit.py` | fairness check |
| `demo.py`, `app.py` | the demo and the web app |
