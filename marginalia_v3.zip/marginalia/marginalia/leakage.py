"""Leakage detector: did the simulated student use knowledge it is supposed to lack?

Two checks:
1. Self-declared: a forbidden concept appears in `concepts_used`.
2. Textual: a sentence of the think-aloud mentions a forbidden concept WITHOUT hedging
   language ("I don't know", "unfamiliar", ...), i.e. the student talks about it confidently.
"""
import re

HEDGES = ["don't know", "do not know", "not sure", "unfamiliar", "no idea", "confus",
          "never seen", "never learned", "haven't learned", "don't understand",
          "do not understand", "stuck", "can't", "cannot", "not familiar", "lost", "unclear", "what is", "what does", "?"]


def _aliases(concept: str) -> set[str]:
    """Surface forms of a concept name: snake_case, spaced, and naive singular ('limits' -> 'limit')."""
    spaced = concept.lower().replace("_", " ")
    forms = {concept.lower(), spaced}
    if spaced.endswith("s") and len(spaced) > 4:
        forms.add(spaced[:-1])
    return forms


def detect(trace, persona: dict, graph=None) -> list[str]:
    forbidden = set(persona["unknown"])
    leaked = set()

    used = {u.lower().replace(" ", "_") for u in trace.concepts_used}
    leaked |= forbidden & used

    sentences = re.split(r"(?<=[.!?])\s+", trace.think_aloud)
    for c in forbidden:
        for s in sentences:
            low = s.lower()
            if any(a in low for a in _aliases(c)) and not any(h in low for h in HEDGES):
                leaked.add(c)
    return sorted(leaked)
