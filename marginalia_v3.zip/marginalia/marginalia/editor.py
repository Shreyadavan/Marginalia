"""Editor agent: propose a minimal fix for the most confusing chunks, then re-simulate."""
from . import concepts, config, llm
from .chunker import Chunk
from .pipeline import Analysis, simulate_with_critic
from .scoring import confusion_score

SYSTEM = """You are a careful course editor. Given a passage and the specific points where simulated
students got lost, make the SMALLEST edit that fixes them: add a one-line definition, insert a missing
reasoning step, add a short worked example, or rephrase an idiom. Do not rewrite the passage or change
its meaning. Return ONLY JSON:
{"edit_type": "definition|worked_example|reasoning_step|rephrase", "rationale": "one sentence",
 "revised_text": "the full revised passage"}"""


def collect_issues(analysis: Analysis, chunk_id: int) -> dict:
    issues = {"unknown_terms": set(), "hidden_prereqs": set(), "skipped_steps": set(), "personas": set()}
    for t in analysis.traces:
        if t.chunk_id == chunk_id and t.persona_id != "control":
            issues["unknown_terms"] |= set(t.unknown_terms)
            issues["hidden_prereqs"] |= set(t.hidden_prereqs)
            issues["skipped_steps"] |= set(t.skipped_steps)
            if t.unknown_terms or t.hidden_prereqs or t.skipped_steps:
                issues["personas"].add(t.persona_id)
    return {k: sorted(v) for k, v in issues.items()}


def propose_edit(chunk: Chunk, issues: dict) -> dict:
    if llm.MOCK:
        return _mock_edit(chunk, issues)
    user = f"PASSAGE:\n{chunk.text}\n\nPROBLEMS FOUND:\n{issues}"
    data = llm.call_json(SYSTEM, user, max_tokens=1500)
    return {"edit_type": data.get("edit_type", "definition"),
            "rationale": data.get("rationale", ""),
            "revised_text": data.get("revised_text", chunk.text)}


def _mock_edit(chunk: Chunk, issues: dict) -> dict:
    gloss = concepts.load_glossary()
    notes = []
    for c in sorted(set(issues["hidden_prereqs"]) | {t.replace(" ", "_") for t in issues["unknown_terms"]}):
        if c in gloss:
            notes.append(f"> **Quick definition ({c.replace('_', ' ')}):** {gloss[c]['definition']}")
    revised = ("\n".join(notes) + "\n\n" + chunk.text) if notes else chunk.text
    return {"edit_type": "definition", "rationale": "Insert one-line definitions for terms students lacked.",
            "revised_text": revised}


def improve(analysis: Analysis, top_n: int = 3) -> list[dict]:
    """Edit the top-N most confusing chunks, re-run the simulation, report before/after."""
    scores = analysis.chunk_scores().sort_values(ascending=False)
    results = []
    for cid in scores.index[:top_n]:
        if scores[cid] < config.CONFUSION_THRESHOLD:
            continue
        chunk = analysis.chunks[cid]
        edit = propose_edit(chunk, collect_issues(analysis, cid))
        new_chunk = Chunk(cid, edit["revised_text"])
        new_traces = [simulate_with_critic(new_chunk, p, analysis.graph, analysis.chunk_concepts)
                      for p in analysis.personas]
        after = sum(confusion_score(t) for t in new_traces) / len(new_traces)
        results.append({"chunk": cid, "before": round(float(scores[cid]), 2), "after": round(after, 2),
                        "gain": round(float(scores[cid]) - after, 2), **edit,
                        "original_text": chunk.text})
    return results
