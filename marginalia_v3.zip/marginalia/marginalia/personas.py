"""Learner personas defined by KNOWLEDGE STATE (not demographics).

A persona masters every concept whose prerequisite-depth is <= mastery_depth,
partially knows the next layer ("weak"), and does not know anything deeper.
This works for any course, because depth comes from the extracted prerequisite graph.
"""
TEMPLATES = [
    {"id": "control", "label": "Well-prepared (control)", "plain": "Well-prepared student", "desc": "knows all the background; the baseline", "mastery_depth": 999,
     "language_level": "native", "reading_habit": "reads everything carefully",
     "idiom_sensitive": False},
    {"id": "prereq_gap", "label": "Prerequisite gap", "plain": "Student missing the basics", "desc": "has not yet learned the earlier topics this lecture builds on", "mastery_depth": 0,
     "language_level": "native", "reading_habit": "reads carefully but lacks background",
     "idiom_sensitive": False},
    {"id": "adult_returner", "label": "Returning adult learner", "plain": "Returning adult learner", "desc": "studied this years ago; rusty on notation; skims", "mastery_depth": 1,
     "language_level": "native", "reading_habit": "skims examples, skips proofs, rusty on notation",
     "idiom_sensitive": False},
    {"id": "non_native", "label": "Non-native English reader", "plain": "Non-native English reader", "desc": "knows the subject but trips on idioms and informal phrases", "mastery_depth": 2,
     "language_level": "B1 English", "reading_habit": "reads slowly, translates idioms literally",
     "idiom_sensitive": True},
    {"id": "strong_math_weak_reading", "label": "Strong maths, weak reading", "plain": "Numbers-first student", "desc": "comfortable with maths, skips long written explanations", "mastery_depth": 2,
     "language_level": "native", "reading_habit": "skips prose, jumps to equations and examples",
     "idiom_sensitive": False},
]


def build_personas(graph, ids=None) -> list[dict]:
    personas = []
    for t in TEMPLATES:
        if ids and t["id"] not in ids:
            continue
        md = t["mastery_depth"]
        mastered, weak, unknown = [], [], []
        for node, data in graph.nodes(data=True):
            d = data.get("depth", 0)
            (mastered if d <= md else weak if d == md + 1 else unknown).append(node)
        personas.append({**t, "mastered": sorted(mastered), "weak": sorted(weak),
                         "unknown": sorted(unknown)})
    return personas
