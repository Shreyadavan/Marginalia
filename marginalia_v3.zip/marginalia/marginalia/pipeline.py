"""Orchestrates: chunk -> concepts -> graph -> personas -> simulated reading -> scores."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass

import pandas as pd

from . import concepts, config, leakage, reader, scoring
from .chunker import Chunk, chunk_text
from .personas import build_personas


@dataclass
class Analysis:
    chunks: list
    graph: object
    chunk_concepts: dict
    personas: list
    traces: list
    df: pd.DataFrame

    @property
    def leakage_rate(self) -> float:
        return float(self.df["leaked"].mean()) if len(self.df) else 0.0

    @property
    def first_attempt_leakage_rate(self) -> float:
        return float(self.df["first_attempt_leaked"].mean()) if len(self.df) else 0.0

    def chunk_scores(self) -> pd.Series:
        return self.df.groupby("chunk")["confusion"].mean()


def simulate_with_critic(chunk: Chunk, persona: dict, graph, chunk_concepts: dict,
                         mode: str = "critic"):
    """mode='plain': single pass. mode='critic': re-run when the leakage detector fires."""
    trace = reader.simulate(chunk, persona, graph, chunk_concepts)
    leaked = leakage.detect(trace, persona, graph)
    first_leaked = bool(leaked)
    attempts = 1
    if mode == "critic":
        while leaked and attempts <= config.LEAK_RETRIES:
            trace = reader.simulate(chunk, persona, graph, chunk_concepts,
                                    strict=leaked, salt=f"retry{attempts}")
            leaked = leakage.detect(trace, persona, graph)
            attempts += 1
    trace.leaked, trace.attempts, trace.first_attempt_leaked = leaked, attempts, first_leaked
    return trace


def simulate_all(chunks, personas, graph, chunk_concepts, mode="critic", progress=None):
    jobs = [(c, p) for c in chunks for p in personas]
    traces, done = [], 0
    with ThreadPoolExecutor(max_workers=config.MAX_WORKERS) as ex:
        futs = [ex.submit(simulate_with_critic, c, p, graph, chunk_concepts, mode) for c, p in jobs]
        for f in as_completed(futs):
            traces.append(f.result())
            done += 1
            if progress:
                progress(done / len(jobs))
    return sorted(traces, key=lambda t: (t.persona_id, t.chunk_id))


def run(text: str, persona_ids=None, mode: str = "critic", progress=None) -> Analysis:
    chunks = chunk_text(text)
    per_chunk, requires = concepts.extract(chunks)
    graph = concepts.build_graph(per_chunk, requires)
    personas = build_personas(graph, persona_ids)
    traces = simulate_all(chunks, personas, graph, per_chunk, mode, progress)
    return Analysis(chunks, graph, per_chunk, personas, traces, scoring.to_dataframe(traces))
