"""Load course material from .md/.txt/.pdf/.docx (path or uploaded bytes) into plain text."""
import io
import re
from pathlib import Path


def _clean_pdf_text(raw: str) -> str:
    """PDF extraction hard-wraps lines; re-join lines into paragraphs, keep blank-line breaks."""
    raw = raw.replace("\r", "")
    raw = re.sub(r"-\n(?=[a-z])", "", raw)            # undo hyphenation at line ends
    paras = re.split(r"\n\s*\n", raw)
    return "\n\n".join(re.sub(r"\s*\n\s*", " ", p).strip() for p in paras if p.strip())


def _read_pdf(data: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise RuntimeError("PDF support needs pypdf: pip install pypdf") from e
    reader = PdfReader(io.BytesIO(data))
    pages = [(p.extract_text() or "") for p in reader.pages]
    text = _clean_pdf_text("\n\n".join(pages))
    if len(text.split()) < 20:
        raise ValueError("No extractable text in this PDF (scanned image?). Run OCR first.")
    return text


def _read_docx(data: bytes) -> str:
    try:
        import docx
    except ImportError as e:
        raise RuntimeError("Word support needs python-docx: pip install python-docx") from e
    doc = docx.Document(io.BytesIO(data))
    out = []
    for p in doc.paragraphs:
        if not p.text.strip():
            continue
        level = p.style.name.replace("Heading ", "") if p.style.name.startswith("Heading") else None
        out.append(f"{'#' * int(level)} {p.text}" if level and level.isdigit() else p.text)
    return "\n\n".join(out)


def load_bytes(data: bytes, filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        return _read_pdf(data)
    if ext == ".docx":
        return _read_docx(data)
    return data.decode("utf-8", errors="replace")


def load_path(path) -> str:
    p = Path(path)
    return load_bytes(p.read_bytes(), p.name)
