"""Reader agent: an LLM that reads one chunk while pretending to be a specific student."""
import re

from . import llm
from .chunker import Chunk
from .schema import Trace

SYSTEM = """You role-play a specific university student reading course material for the first time.
You must behave as if you know ONLY what the profile says. Genuine ignorance matters: if the passage
depends on a concept in your UNKNOWN list, you cannot understand it, so say so; do NOT quietly use
your own background knowledge to fill the gap. Return ONLY JSON."""

PROMPT = """STUDENT PROFILE
- Mastered concepts: {mastered}
- Weak (only partial understanding): {weak}
- UNKNOWN (you have never learned these): {unknown}
- Language level: {language}
- Reading habit: {habit}

PASSAGE
\"\"\"
{chunk}
\"\"\"

Read the passage as this student. Return ONLY JSON with exactly these keys:
{{
  "think_aloud": "2-4 sentences of what you are thinking while reading, in first person",
  "unknown_terms": ["terms/words you do not understand"],
  "unstated_assumptions": ["things the text assumes you know but doesn't say"],
  "skipped_steps": ["places where a reasoning step is missing"],
  "hidden_prereqs": ["snake_case concept names you would need first but lack"],
  "concepts_used": ["snake_case concepts you relied on to understand the passage"],
  "confidence": 0.0-1.0 (how well you understood),
  "would_stop_reading": true/false
}}
{strict}"""

STRICT = ("\nIMPORTANT: a previous attempt wrongly relied on concepts this student does not know: "
          "{leaked}. Do NOT use them. If the passage depends on them, flag them as unknown.")

IDIOMS = ["plug in", "blow up", "intuitively", "rule of thumb", "zoom in", "of course",
          "in a nutshell", "it turns out"]
JUMP_MARKERS = ["it follows", "clearly", "obviously", "trivially", "hence", "therefore",
                "it is easy to see", "one can show"]


def is_explained(text: str, concept: str) -> bool:
    """True if the chunk contains an inserted 'Quick definition (concept)' note."""
    return f"quick definition ({concept.replace('_', ' ')})" in text.lower()


def simulate(chunk: Chunk, persona: dict, graph, chunk_concepts: dict,
             strict=None, salt: str = "") -> Trace:
    if llm.MOCK:
        return _mock(chunk, persona, graph, chunk_concepts)
    prompt = PROMPT.format(
        mastered=persona["mastered"], weak=persona["weak"], unknown=persona["unknown"],
        language=persona["language_level"], habit=persona["reading_habit"],
        chunk=chunk.text, strict=STRICT.format(leaked=strict) if strict else "")
    data = llm.call_json(SYSTEM, prompt, temperature=0.4, salt=salt)
    return Trace.from_dict(data, chunk.id, persona["id"])


def _mock(chunk, persona, graph, chunk_concepts) -> Trace:
    """Offline heuristic reader so the whole pipeline runs without an API key."""
    text, low = chunk.text, chunk.text.lower()
    unknown, weak, mastered = set(persona["unknown"]), set(persona["weak"]), set(persona["mastered"])
    ut, ua, ss, hp, used = [], [], [], [], []
    for c in chunk_concepts.get(chunk.id, []):
        if is_explained(text, c):
            used.append(c)
            continue
        label = c.replace("_", " ")
        if c in unknown:
            ut.append(label)
            hp += [p for p in graph.predecessors(c)
                   if p not in mastered and not is_explained(text, p)]
        elif c in weak:
            ua.append(f"assumes you are comfortable with {label}")
        else:
            used.append(c)
    if persona["mastery_depth"] <= 1:
        ss += [f"jump signalled by '{m}'" for m in JUMP_MARKERS if m in low]
    if persona["idiom_sensitive"]:
        ut += [i for i in IDIOMS if i in low]
    hp = sorted(set(hp))
    conf = 1 - 0.15 * len(ut) - 0.08 * len(ua) - 0.12 * len(ss) - 0.10 * len(hp)
    conf = round(min(1.0, max(0.05, conf)), 2)
    think = _mock_think(ut, ua, ss, hp, conf)
    return Trace(chunk_id=chunk.id, persona_id=persona["id"], think_aloud=think,
                 unknown_terms=ut, unstated_assumptions=ua, skipped_steps=ss,
                 hidden_prereqs=hp, concepts_used=used, confidence=conf,
                 would_stop_reading=conf < 0.3)


def _mock_think(ut, ua, ss, hp, conf) -> str:
    """Readable first-person think-aloud for mock mode (always hedges when it names unknowns)."""
    if not (ut or ua or ss or hp):
        return "[mock] This reads fine to me; I know everything it relies on."
    parts = []
    if ut:
        shown = ", ".join(f"'{t}'" for t in ut[:3])
        parts.append(f"I get stuck on {shown}; I haven't learned {'that' if len(ut) == 1 else 'those'} yet.")
    if ss:
        parts.append("The author jumps ahead without showing why, and I can't follow the step.")
    if ua:
        parts.append(f"The text assumes I'm comfortable with {ua[0].replace('assumes you are comfortable with ', '')}, but I'm not sure I am.")
    if hp:
        parts.append(f"I'd need to learn {', '.join(h.replace('_', ' ') for h in hp[:2])} first, and I haven't learned that yet.")
    if conf < 0.3:
        parts.append("Honestly, I would stop reading here.")
    return "[mock] " + " ".join(parts)
