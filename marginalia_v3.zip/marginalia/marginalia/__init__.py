"""Marginalia: simulate confused student readers to find weak spots in course material."""
