"""Central settings. Tweak weights here to change how confusion is scored."""

MAX_CHUNK_WORDS = 160        # chunk size for the chunker
LEAK_RETRIES = 2             # critic-loop retries when a trace leaks forbidden knowledge
MAX_WORKERS = 4              # parallel LLM calls
MAX_SCORE = 10.0             # confusion score is capped to 0..10
CONFUSION_THRESHOLD = 4.0    # chunks above this are "hot" and get edit suggestions

WEIGHTS = {
    "unknown_terms": 1.0,
    "unstated_assumptions": 1.0,
    "skipped_steps": 1.5,
    "hidden_prereqs": 1.2,
    "low_confidence": 3.0,   # multiplied by (1 - confidence)
}
