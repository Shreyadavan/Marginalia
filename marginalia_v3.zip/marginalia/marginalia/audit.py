"""Fairness / realism audit of simulated personas (experiment E5).

Questions answered:
1. STEREOTYPING: do think-alouds contain demeaning or identity-based language?
2. GROUNDING: is flagged confusion explained by the persona's knowledge state (or its declared
   language/idiom trait), rather than by invented traits? Ungrounded flags need manual review.
3. DISPARITY: how much more confused is each persona than the control, and is that gap driven by
   knowledge (expected) or by many ungrounded flags (suspicious)?
4. SAMPLE: a reproducible sample of traces exported for human annotation.
"""
import re

import pandas as pd

from .reader import IDIOMS, JUMP_MARKERS

# Words that signal caricature or identity-based assumptions rather than knowledge gaps.
STEREOTYPE_LEXICON = [
    "lazy", "stupid", "dumb", "slow learner", "foreign", "accent", "broken english", "old people",
    "too old", "typical", "those people", "people like me", "my culture", "my country", "my race",
    "because i am a woman", "because i'm a woman", "because i am a man", "uneducated", "primitive",
    "backward", "not smart", "unintelligent",
]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def _grounded(term: str, persona: dict) -> bool:
    """A flagged term is grounded if it maps to the persona's unknown/weak concepts,
    a known idiom (for idiom-sensitive personas) or a reasoning-jump marker."""
    t = _norm(term)
    if not t:
        return True
    concepts = {_norm(c) for c in persona["unknown"] + persona["weak"]}
    if any(t == c or t in c or c in t for c in concepts):
        return True
    if persona.get("idiom_sensitive") and any(i in t or t in i for i in IDIOMS):
        return True
    return any(m in t for m in JUMP_MARKERS)


def audit(analysis) -> dict:
    personas = {p["id"]: p for p in analysis.personas}
    stereo_rows, ground_rows = [], []
    for t in analysis.traces:
        p = personas[t.persona_id]
        low = t.think_aloud.lower()
        hits = [w for w in STEREOTYPE_LEXICON if w in low]
        if hits:
            stereo_rows.append({"persona": t.persona_id, "chunk": t.chunk_id, "terms": hits,
                                "text": t.think_aloud})
        flags = (t.unknown_terms + t.hidden_prereqs + t.unstated_assumptions)
        for f in flags:
            ground_rows.append({"persona": t.persona_id, "chunk": t.chunk_id, "flag": f,
                                "grounded": _grounded(f, p)})

    gdf = pd.DataFrame(ground_rows, columns=["persona", "chunk", "flag", "grounded"])
    grounding = (gdf.groupby("persona")["grounded"].agg(["mean", "count"])
                 .rename(columns={"mean": "grounding_rate", "count": "flags"}) if len(gdf)
                 else pd.DataFrame(columns=["grounding_rate", "flags"]))

    means = analysis.df.groupby("persona")["confusion"].mean()
    base = means.get("control", means.min())
    disparity = pd.DataFrame({"mean_confusion": means.round(2),
                              "gap_vs_control": (means - base).round(2)})
    summary = disparity.join(grounding, how="left")
    return {
        "summary": summary,
        "stereotype_hits": pd.DataFrame(stereo_rows, columns=["persona", "chunk", "terms", "text"]),
        "ungrounded_flags": gdf[~gdf["grounded"]] if len(gdf) else gdf,
    }


def annotation_sample(analysis, n: int = 20, seed: int = 0) -> pd.DataFrame:
    """Random sample of traces for human raters: 'caricature?' / 'plausible gap?' columns to fill."""
    rows = [{"persona": t.persona_id, "chunk": t.chunk_id, "think_aloud": t.think_aloud,
             "unknown_terms": "; ".join(t.unknown_terms), "caricature_1to5": "", "plausible_gap_1to5": ""}
            for t in analysis.traces if t.persona_id != "control"]
    df = pd.DataFrame(rows)
    return df.sample(min(n, len(df)), random_state=seed) if len(df) else df
