"""Split course material into paragraph-sized chunks, keeping headings with their text."""
import re
from dataclasses import dataclass

from . import config


@dataclass
class Chunk:
    id: int
    text: str


def _split_long(para: str, max_words: int) -> list[str]:
    """Break an over-long paragraph (common in PDF extracts) at sentence boundaries."""
    if len(para.split()) <= max_words * 1.5 or para.startswith("#"):
        return [para]
    pieces, cur, n = [], [], 0
    for s in re.split(r"(?<=[.!?])\s+", para):
        w = len(s.split())
        if cur and n + w > max_words:
            pieces.append(" ".join(cur))
            cur, n = [], 0
        cur.append(s)
        n += w
    if cur:
        pieces.append(" ".join(cur))
    return pieces


def chunk_text(text: str, max_words: int = config.MAX_CHUNK_WORDS) -> list[Chunk]:
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks: list[Chunk] = []
    buf: list[str] = []
    n = 0

    def flush():
        nonlocal buf, n
        if buf:
            chunks.append(Chunk(len(chunks), "\n\n".join(buf)))
        buf, n = [], 0

    paras = [piece for p in paras for piece in _split_long(p, max_words)]
    for p in paras:
        w = len(p.split())
        if p.startswith("#") and buf:      # headings start a new chunk
            flush()
        elif buf and n + w > max_words:
            flush()
        buf.append(p)
        n += w
    flush()
    return chunks
