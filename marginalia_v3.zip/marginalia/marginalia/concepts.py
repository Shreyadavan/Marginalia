"""Concept extraction + prerequisite graph. The graph defines what 'knowing' means."""
import json
import re
from pathlib import Path

import networkx as nx

from . import llm

GLOSSARY_PATH = Path(__file__).resolve().parent.parent / "data" / "glossary.json"

SYSTEM = """You analyse university course material. For the passage, list the key concepts it
USES or INTRODUCES, and for each concept list the concepts a reader must already understand first
(include prerequisites that are NOT taught in this course, e.g. high-school background).
Use short snake_case names. Reuse names from the 'existing concept names' list when the concept is the same.
Return ONLY JSON: {"concepts": [{"name": "limits", "requires": ["functions"]}]}"""


def norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def load_glossary() -> dict:
    return json.loads(GLOSSARY_PATH.read_text()) if GLOSSARY_PATH.exists() else {}


def extract(chunks):
    """Return (per_chunk: {chunk_id: [concept]}, requires: {concept: [prereq]})."""
    return _mock_extract(chunks) if llm.MOCK else _llm_extract(chunks)


def _llm_extract(chunks):
    per_chunk, requires, known = {}, {}, []
    for ch in chunks:
        data = llm.call_json(SYSTEM, f"Existing concept names: {known}\n\nPASSAGE:\n{ch.text}")
        items = data.get("concepts", []) if isinstance(data, dict) else data
        names = []
        for it in items:
            name = norm(it.get("name", ""))
            if not name:
                continue
            names.append(name)
            reqs = [norm(r) for r in it.get("requires", []) if norm(r) and norm(r) != name]
            requires[name] = sorted(set(requires.get(name, [])) | set(reqs))
            if name not in known:
                known.append(name)
        per_chunk[ch.id] = names
    return per_chunk, requires


def _mock_extract(chunks):
    """Keyword-based extraction using data/glossary.json (works offline)."""
    gloss = load_glossary()
    per_chunk, requires = {}, {}

    def add_closure(c):
        if c in requires:
            return
        requires[c] = list(gloss[c]["requires"])
        for r in requires[c]:
            if r in gloss:
                add_closure(r)

    for ch in chunks:
        low = ch.text.lower()
        found = [c for c, g in gloss.items() if any(k in low for k in g["keywords"])]
        per_chunk[ch.id] = found
        for c in found:
            add_closure(c)
    return per_chunk, requires


def build_graph(per_chunk: dict, requires: dict) -> nx.DiGraph:
    """Edge A -> B means 'A is a prerequisite of B'. Adds depth + chunk attributes."""
    g = nx.DiGraph()
    for c, reqs in requires.items():
        g.add_node(c)
        for r in reqs:
            g.add_edge(r, c)
    for names in per_chunk.values():
        g.add_nodes_from(names)
    while True:  # LLMs sometimes produce cycles; break them
        try:
            cyc = nx.find_cycle(g)
        except nx.NetworkXNoCycle:
            break
        g.remove_edge(*cyc[-1][:2])
    for depth, gen in enumerate(nx.topological_generations(g)):
        for n in gen:
            g.nodes[n]["depth"] = depth
    for cid, names in per_chunk.items():
        for n in names:
            g.nodes[n].setdefault("chunks", []).append(cid)
    return g
