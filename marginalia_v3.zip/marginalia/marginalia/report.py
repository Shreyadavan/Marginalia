"""Plain-English findings and a shareable HTML report (no extra libraries needed)."""
import html
from collections import Counter

from . import config
from .reader import IDIOMS
from .scoring import confusion_score, heat_matrix


def level(score: float) -> str:
    return "Hard" if score >= 6 else "Medium" if score >= 3 else "Easy"


def chunk_title(chunk) -> str:
    first = chunk.text.strip().splitlines()[0].lstrip("# ").strip()
    return first if len(first) <= 60 else first[:57] + "..."


def plain_name(analysis, persona_id: str) -> str:
    for p in analysis.personas:
        if p["id"] == persona_id:
            return p.get("plain", p["label"])
    return persona_id


def findings(analysis) -> list[dict]:
    """One entry per paragraph (chunk): how hard it is, for whom, why, and what to change."""
    out = []
    scores = analysis.chunk_scores()
    for cid in sorted(scores.index):
        traces = [t for t in analysis.traces if t.chunk_id == cid and t.persona_id != "control"]
        who = sorted({plain_name(analysis, t.persona_id) for t in traces if confusion_score(t) >= 3})
        terms, prereqs, steps = Counter(), Counter(), Counter()
        for t in traces:
            terms.update(t.unknown_terms)
            prereqs.update(h.replace("_", " ") for h in t.hidden_prereqs)
            steps.update(t.skipped_steps)
        idioms = [x for x in terms if x in IDIOMS]
        words = [x for x in terms if x not in IDIOMS]
        advice = []
        if words:
            advice.append("Define these terms where they first appear: " + ", ".join(sorted(words)) + ".")
        if prereqs:
            advice.append("Add a one-line reminder of the background: " + ", ".join(sorted(prereqs)) + ".")
        if steps:
            advice.append("Show the missing reasoning step (the text jumps ahead with words like 'clearly' or 'hence').")
        if idioms:
            advice.append("Rephrase informal phrases: " + ", ".join(sorted(idioms)) + ".")
        s = float(scores[cid])
        out.append({"chunk": cid, "title": chunk_title(analysis.chunks[cid]), "score": round(s, 1),
                    "level": level(s), "who": who, "terms": sorted(words), "prereqs": sorted(prereqs),
                    "idioms": sorted(idioms), "steps": len(steps), "advice": advice})
    return out


def persona_summary(analysis) -> list[dict]:
    """How many paragraphs each kind of student found hard (score >= 3)."""
    n = len(analysis.chunks)
    rows = []
    for p in analysis.personas:
        sub = analysis.df[analysis.df.persona == p["id"]]
        rows.append({"student": p.get("plain", p["label"]), "about": p.get("desc", ""),
                     "hard_paragraphs": int((sub.confusion >= 3).sum()), "total": n,
                     "average": round(float(sub.confusion.mean()), 1)})
    return rows


def summary_text(analysis) -> str:
    f = findings(analysis)
    hardest = max(f, key=lambda x: x["score"])
    easiest = min(f, key=lambda x: x["score"])
    lines = [f"We read your material as {len(analysis.personas)} kinds of student, paragraph by paragraph.", ""]
    for r in persona_summary(analysis):
        lines.append(f"- {r['student']} ({r['about']}): struggled with {r['hard_paragraphs']} of {r['total']} paragraphs.")
    lines += ["", f"Hardest paragraph: #{hardest['chunk']} '{hardest['title']}' (score {hardest['score']}/10).",
              f"Easiest paragraph: #{easiest['chunk']} '{easiest['title']}' (score {easiest['score']}/10)."]
    return "\n".join(lines)


def _color(score: float) -> str:
    """Green (clear) to red (confusing) as a hex colour that every viewer understands."""
    import colorsys
    x = max(0.0, min(1.0, score / config.MAX_SCORE))
    red, green, blue = colorsys.hls_to_rgb((120 * (1 - x)) / 360, 0.86 - 0.18 * x, 0.70)
    return "#%02x%02x%02x" % (int(red * 255), int(green * 255), int(blue * 255))


def html_report(analysis, edits=None, title="Marginalia report") -> str:
    e = html.escape
    heat = heat_matrix(analysis.df)
    names = {p["id"]: p.get("plain", p["label"]) for p in analysis.personas}
    rows = ["<tr><th>Student type</th>" + "".join(f"<th>P{c}</th>" for c in heat.columns) + "</tr>"]
    for pid, vals in heat.iterrows():
        cells = "".join(f'<td style="background:{_color(v)}">{v:.1f}</td>' for v in vals)
        rows.append(f"<tr><th>{e(names.get(pid, pid))}</th>{cells}</tr>")
    items = []
    for f in findings(analysis):
        who = ", ".join(f["who"]) or "nobody in particular"
        adv = "".join(f"<li>{e(a)}</li>" for a in f["advice"]) or "<li>No change needed.</li>"
        items.append(f'<div class="card"><h3>Paragraph {f["chunk"]}: {e(f["title"])} '
                     f'<span class="pill" style="background:{_color(f["score"])}">{f["level"]} {f["score"]}/10</span></h3>'
                     f"<p><b>Hard for:</b> {e(who)}</p><ul>{adv}</ul></div>")
    fixes = ""
    if edits:
        fixes = "<h2>Tested fixes</h2>" + "".join(
            f'<div class="card"><h3>Paragraph {r["chunk"]}: confusion {r["before"]} &rarr; {r["after"]} (improved by {r["gain"]})</h3>'
            f'<p>{e(r["rationale"])}</p><div class="two"><div><b>Original</b><pre>{e(r["original_text"])}</pre></div>'
            f'<div><b>Revised</b><pre>{e(r["revised_text"])}</pre></div></div></div>' for r in edits)
    summ = e(summary_text(analysis)).replace("\n", "<br>")
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{e(title)}</title><style>
body{{font-family:Georgia,serif;max-width:980px;margin:30px auto;padding:0 16px;color:#1b2330}}
table{{border-collapse:collapse;margin:12px 0}}td,th{{border:1px solid #bbb;padding:6px 10px;text-align:center}}
th{{background:#eef2f6}}.card{{border:1px solid #d5dbe2;border-radius:8px;padding:10px 16px;margin:12px 0}}
.pill{{font-size:.75em;padding:2px 8px;border-radius:10px;margin-left:8px}}.two{{display:flex;gap:12px}}
.two div{{flex:1}}pre{{white-space:pre-wrap;background:#f6f7f9;padding:8px;font-size:.85em}}
</style></head><body><h1>{e(title)}</h1>
<p>Simulated students with limited knowledge read your material. Scores run from 0 (clear) to 10 (very confusing).</p>
<h2>Summary</h2><p>{summ}</p><h2>Confusion heatmap</h2><table>{''.join(rows)}</table>
<h2>Paragraph by paragraph</h2>{''.join(items)}{fixes}
<p><i>Generated by Marginalia. Offline demo mode uses a keyword heuristic, so treat mock scores as illustrative.</i></p>
</body></html>"""
