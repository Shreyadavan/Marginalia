"""Thin wrapper around the Anthropic API: JSON parsing, retries, disk cache, mock switch."""
import hashlib
import json
import os
import re
import time
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # dotenv is optional
    pass

MODEL = os.getenv("MARGINALIA_MODEL", "claude-sonnet-4-6")
MOCK = os.getenv("MARGINALIA_MOCK", "0") == "1" or not os.getenv("ANTHROPIC_API_KEY")
CACHE_DIR = Path(".cache")
_client = None


def set_mock(value: bool) -> None:
    """Switch mock mode on/off at runtime (used by the Streamlit toggle)."""
    global MOCK
    MOCK = value


def _get_client():
    global _client
    if _client is None:
        from anthropic import Anthropic
        _client = Anthropic()
    return _client


def extract_json(text: str):
    """Pull the first JSON object/array out of a model reply (tolerates ``` fences)."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    starts = [i for i in (text.find("{"), text.find("[")) if i != -1]
    if not starts:
        raise ValueError("No JSON found in model output")
    start = min(starts)
    end = max(text.rfind("}"), text.rfind("]"))
    return json.loads(text[start:end + 1])


def call_json(system: str, user: str, max_tokens: int = 1200,
              temperature: float = 0.2, salt: str = ""):
    """Call the model and return parsed JSON. Results are cached on disk."""
    key = hashlib.sha256(json.dumps([MODEL, system, user, temperature, salt]).encode()).hexdigest()
    path = CACHE_DIR / f"{key}.json"
    if path.exists():
        return json.loads(path.read_text())

    last_err = None
    for attempt in range(3):
        try:
            resp = _get_client().messages.create(
                model=MODEL,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
            data = extract_json(text)
            CACHE_DIR.mkdir(exist_ok=True)
            path.write_text(json.dumps(data))
            return data
        except Exception as e:  # network, rate limit, bad JSON -> retry
            last_err = e
            time.sleep(2 ** attempt)
    raise RuntimeError(f"LLM call failed after retries: {last_err}")
