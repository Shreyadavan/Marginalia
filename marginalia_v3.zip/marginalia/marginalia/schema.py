"""Structured think-aloud trace produced by a simulated reader."""
from dataclasses import dataclass, field, asdict

LIST_FIELDS = ["unknown_terms", "unstated_assumptions", "skipped_steps",
               "hidden_prereqs", "concepts_used"]


def _as_list(v) -> list[str]:
    if v is None:
        return []
    if isinstance(v, str):
        return [v] if v.strip() else []
    return [str(x) for x in v]


@dataclass
class Trace:
    chunk_id: int = 0
    persona_id: str = ""
    think_aloud: str = ""
    unknown_terms: list = field(default_factory=list)
    unstated_assumptions: list = field(default_factory=list)
    skipped_steps: list = field(default_factory=list)
    hidden_prereqs: list = field(default_factory=list)
    concepts_used: list = field(default_factory=list)
    confidence: float = 0.5
    would_stop_reading: bool = False
    leaked: list = field(default_factory=list)
    first_attempt_leaked: bool = False
    attempts: int = 1

    @classmethod
    def from_dict(cls, data: dict, chunk_id: int, persona_id: str) -> "Trace":
        """Validate/coerce raw model JSON into a Trace (models are sloppy about types)."""
        t = cls(chunk_id=chunk_id, persona_id=persona_id)
        t.think_aloud = str(data.get("think_aloud", ""))
        for f in LIST_FIELDS:
            setattr(t, f, _as_list(data.get(f)))
        try:
            t.confidence = min(1.0, max(0.0, float(data.get("confidence", 0.5))))
        except (TypeError, ValueError):
            t.confidence = 0.5
        t.would_stop_reading = bool(data.get("would_stop_reading", False))
        return t

    def to_dict(self) -> dict:
        return asdict(self)
