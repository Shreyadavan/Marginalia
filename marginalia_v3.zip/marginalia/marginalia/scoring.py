"""Turn traces into confusion scores, failure-type breakdowns and heatmap matrices."""
import pandas as pd

from . import config


def confusion_score(t) -> float:
    w = config.WEIGHTS
    raw = (w["unknown_terms"] * len(t.unknown_terms)
           + w["unstated_assumptions"] * len(t.unstated_assumptions)
           + w["skipped_steps"] * len(t.skipped_steps)
           + w["hidden_prereqs"] * len(t.hidden_prereqs)
           + w["low_confidence"] * (1 - t.confidence))
    return round(min(raw, config.MAX_SCORE), 2)


def failure_breakdown(t) -> dict:
    """Map a trace to the three failure types from the project proposal."""
    return {
        "vocabulary_gap": len(t.unknown_terms),
        "skipped_reasoning": len(t.skipped_steps),
        "hidden_prerequisite": len(t.hidden_prereqs) + len(t.unstated_assumptions),
    }


def to_dataframe(traces) -> pd.DataFrame:
    rows = []
    for t in traces:
        rows.append({"persona": t.persona_id, "chunk": t.chunk_id,
                     "confusion": confusion_score(t), "confidence": t.confidence,
                     "stop_reading": t.would_stop_reading, "leaked": len(t.leaked) > 0,
                     "first_attempt_leaked": t.first_attempt_leaked,
                     "attempts": t.attempts, **failure_breakdown(t)})
    return pd.DataFrame(rows)


def heat_matrix(df: pd.DataFrame) -> pd.DataFrame:
    return df.pivot(index="persona", columns="chunk", values="confusion").sort_index(axis=1)
