"""Streamlit app:  streamlit run app.py"""
import difflib
import html
from pathlib import Path

import plotly.express as px
import streamlit as st

from marginalia import audit, config, editor, llm, loader, pipeline, report, scoring
from marginalia.personas import TEMPLATES

st.set_page_config(page_title="Marginalia", page_icon="📝", layout="wide")

CSS = """
<style>
.hero{background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 55%,#db2777 100%);padding:26px 32px;
      border-radius:18px;color:#fff;margin-bottom:18px}
.hero h1{margin:0;font-size:2.5rem;color:#fff;padding:0}
.hero p{margin:6px 0 0 0;font-size:1.12rem;opacity:.96}
.step{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:14px;min-height:150px;
      box-shadow:0 1px 3px rgba(0,0,0,.06)}
.step .ic{font-size:1.7rem}.step b{display:block;margin-top:4px;color:#111827}
.step span{font-size:.86rem;color:#4b5563}
.kpi{background:#f8fafc;border:1px solid #e5e7eb;border-radius:14px;padding:14px 16px}
.kpi .v{font-size:1.9rem;font-weight:700;color:#4f46e5;line-height:1.2}
.kpi .l{font-size:.85rem;color:#6b7280}
.badge{padding:2px 10px;border-radius:999px;font-size:.78rem;font-weight:700}
.card{border:1px solid #e5e7eb;border-left:6px solid var(--c);border-radius:10px;
      padding:10px 16px;margin:10px 0;background:#fff}
.card h4{margin:0 0 4px 0}
.bubble{background:#f3f4f8;border-radius:14px;padding:10px 14px;margin:8px 0}
.bubble small{color:#6b7280}
.quote{border-left:4px solid #c7d2fe;background:#eef2ff;padding:10px 14px;border-radius:8px}
.big{text-align:center;font-size:2.3rem;font-weight:800}
.added{background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 12px;margin:4px 0}
.note{color:#6b7280;font-size:.9rem}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

LEVEL_STYLE = {"Hard": ("#fee2e2", "#b91c1c"), "Medium": ("#fef3c7", "#b45309"), "Easy": ("#dcfce7", "#15803d")}
AVATAR = {"control": "🎓", "prereq_gap": "😕", "adult_returner": "🕰️",
          "non_native": "🌍", "strong_math_weak_reading": "🔢"}
STEPS = [("📄", "Read", "Splits your notes into paragraphs."),
         ("🗺️", "Map", "Works out which topic needs which (limits, then derivative)."),
         ("🧑‍🎓", "Students", "Creates simulated students who each know only part of the map."),
         ("💭", "Think aloud", "An AI plays each student and says where it gets lost."),
         ("🕵️", "Check", "Catches the AI cheating with knowledge the student should not have."),
         ("🔧", "Fix", "Suggests a small fix and re-tests it.")]


def badge(level, text=None):
    bg, fg = LEVEL_STYLE[level]
    return f'<span class="badge" style="background:{bg};color:{fg}">{html.escape(text or level)}</span>'


def kpi(col, label, value, note=""):
    col.markdown(f'<div class="kpi"><div class="l">{html.escape(label)}</div>'
                 f'<div class="v">{html.escape(str(value))}</div><div class="note">{html.escape(note)}</div></div>',
                 unsafe_allow_html=True)


def run_all(text, ids, mode, with_edits):
    bar = st.progress(0.0, text="Simulated students are reading your notes...")
    a = pipeline.run(text, ids or None, mode, lambda p: bar.progress(p))
    bar.empty()
    st.session_state.analysis = a
    st.session_state.edits = editor.improve(a, top_n=3) if with_edits else None


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.header("Settings")
    has_key = bool(llm.os.getenv("ANTHROPIC_API_KEY"))
    mock = st.toggle("Offline demo mode (no API key)", value=llm.MOCK or not has_key, disabled=not has_key,
                     help="Uses a simple keyword program instead of an AI model. "
                          "Add ANTHROPIC_API_KEY to .env to switch it off.")
    llm.set_mock(mock or not has_key)
    mode = st.radio("Cheating control", ["critic", "plain"],
                    help="critic = if a simulated student uses knowledge it should not have, make it try again")
    ids = st.multiselect("Student types", [t["id"] for t in TEMPLATES], default=[t["id"] for t in TEMPLATES],
                         format_func=lambda i: next(t["plain"] for t in TEMPLATES if t["id"] == i))
    st.markdown("---")
    st.caption("Marginalia: a proofreader that reads your notes like a confused student.")

# ------------------------------------------------------------------ hero
st.markdown('<div class="hero"><h1>📝 Marginalia</h1>'
            "<p>A proofreader that reads your lecture notes like a <b>confused student</b>, "
            "so you can fix the confusing parts <b>before</b> the semester starts.</p></div>",
            unsafe_allow_html=True)
if llm.MOCK:
    st.warning("Offline demo mode: a keyword program plays the student, so the scores are illustrative only.")

if "analysis" not in st.session_state:
    st.subheader("How it works")
    cols = st.columns(len(STEPS))
    for i, (col, (ic, title, text)) in enumerate(zip(cols, STEPS), 1):
        col.markdown(f'<div class="step"><div class="ic">{ic}</div><b>{i}. {title}</b><span>{text}</span></div>',
                     unsafe_allow_html=True)
    st.markdown("")
    st.info("**Why it matters:** teachers forget what it feels like not to know something, so notes skip steps "
            "and use unfamiliar words. Usually the teacher finds out only after students fail the exam.")

# ------------------------------------------------------------------ input
st.subheader("1. Choose your material")
src = st.radio("Course material", ["Sample lecture", "Upload file", "Paste text"], horizontal=True,
               label_visibility="collapsed")
text = ""
if src == "Sample lecture":
    text = Path("data/sample_lecture.md").read_text(encoding="utf-8")
    with st.expander("Preview the sample lecture"):
        st.markdown(text)
elif src == "Upload file":
    up = st.file_uploader("PDF, Word, Markdown or text file", type=["pdf", "docx", "md", "txt"])
    if up:
        try:
            text = loader.load_bytes(up.read(), up.name)
            st.caption(f"Extracted {len(text.split())} words from {up.name}")
        except Exception as e:
            st.error(str(e))
else:
    text = st.text_area("Paste lecture notes", height=220)

b1, b2 = st.columns(2)
if b1.button("▶ Analyse", type="primary", disabled=not text.strip(), use_container_width=True):
    run_all(text, ids, mode, with_edits=False)
if b2.button("✨ One-click demo (analyse and test fixes)", disabled=not text.strip(), use_container_width=True):
    run_all(text, ids, mode, with_edits=True)

# ------------------------------------------------------------------ results
a = st.session_state.get("analysis")
if a:
    edits = st.session_state.get("edits")
    finds = report.findings(a)
    people = report.persona_summary(a)
    worst_person = max(people, key=lambda r: r["average"])
    hardest = max(finds, key=lambda f: f["score"])

    st.subheader("2. Results")
    tab_over, tab_adv, tab_mind, tab_fix, tab_trust = st.tabs(
        ["📊 Overview", "📝 Advice per paragraph", "💭 Inside a student's mind", "🔧 Fix and re-test", "🛡️ Can we trust it?"])

    with tab_over:
        k1, k2, k3, k4 = st.columns(4)
        kpi(k1, "Paragraphs read", len(a.chunks), f"by {len(a.personas)} kinds of student")
        kpi(k2, "Hardest paragraph", f"#{hardest['chunk']}", f"{hardest['score']}/10: {hardest['title']}")
        kpi(k3, "Students who struggle most", worst_person["student"], f"average {worst_person['average']}/10")
        kpi(k4, "AI cheating rate", f"{a.leakage_rate:.0%}", "after retries")
        st.markdown("")
        heat = scoring.heat_matrix(a.df)
        heat.index = [report.plain_name(a, i) for i in heat.index]
        heat.columns = [f"Para {c}" for c in heat.columns]
        fig = px.imshow(heat, color_continuous_scale="RdYlGn_r", zmin=0, zmax=config.MAX_SCORE, aspect="auto",
                        text_auto=".1f", labels=dict(color="Confusion"))
        fig.update_layout(height=330, margin=dict(l=10, r=10, t=30, b=10),
                          title="Confusion map: green = clear, red = students get lost")
        st.plotly_chart(fig, use_container_width=True)
        st.info("**How to read it:** a red *column* means the paragraph confuses many students, so fix the paragraph. "
                "A red *row* means one kind of student struggles everywhere, so they need background or simpler wording.")
        st.markdown("**Biggest problems**")
        for f in sorted(finds, key=lambda f: -f["score"])[:3]:
            if f["level"] != "Easy":
                st.markdown(f'<div class="card" style="--c:{LEVEL_STYLE[f["level"]][1]}"><h4>Paragraph {f["chunk"]}: '
                            f'{html.escape(f["title"])} {badge(f["level"], f["level"] + " " + str(f["score"]) + "/10")}</h4>'
                            f'Hard for: {html.escape(", ".join(f["who"]) or "nobody in particular")}</div>',
                            unsafe_allow_html=True)
        st.download_button("⬇ Download shareable report (HTML)", report.html_report(a, edits),
                           "marginalia_report.html", mime="text/html")

    with tab_adv:
        st.caption("What to change, paragraph by paragraph, in plain English.")
        for f in finds:
            bullets = "".join(f"<li>{html.escape(x)}</li>" for x in f["advice"]) or "<li>No change needed.</li>"
            st.markdown(f'<div class="card" style="--c:{LEVEL_STYLE[f["level"]][1]}"><h4>Paragraph {f["chunk"]}: '
                        f'{html.escape(f["title"])} {badge(f["level"], f["level"] + " " + str(f["score"]) + "/10")}</h4>'
                        f'<div class="note">Hard for: {html.escape(", ".join(f["who"]) or "nobody in particular")}</div>'
                        f"<ul>{bullets}</ul></div>", unsafe_allow_html=True)

    with tab_mind:
        cid = st.selectbox("Choose a paragraph", [c.id for c in a.chunks],
                           format_func=lambda i: f"{i}: {report.chunk_title(a.chunks[i])}")
        st.markdown('<div class="quote">' + html.escape(a.chunks[cid].text).replace("\n", "<br>") + "</div>",
                    unsafe_allow_html=True)
        st.markdown("**What each student thinks while reading:**")
        for t in a.traces:
            if t.chunk_id != cid:
                continue
            name = report.plain_name(a, t.persona_id)
            sc = scoring.confusion_score(t)
            lvl = report.level(sc)
            cheat = (" ⚠️ used knowledge it should not have: " + ", ".join(t.leaked)) if t.leaked else ""
            missing = ", ".join(h.replace("_", " ") for h in t.hidden_prereqs) or "nothing"
            st.markdown(f'<div class="bubble"><b>{AVATAR.get(t.persona_id, "🧑")} {html.escape(name)}</b> '
                        f'{badge(lvl, str(sc) + "/10")}{html.escape(cheat)}<br>'
                        f'<i>{html.escape(t.think_aloud)}</i><br><small>Missing background: {html.escape(missing)}</small></div>',
                        unsafe_allow_html=True)
        with st.expander("Prerequisite map (what depends on what)"):
            st.dataframe([{"topic": n.replace("_", " "), "level": d.get("depth"),
                           "needs first": ", ".join(p.replace("_", " ") for p in sorted(a.graph.predecessors(n)))}
                          for n, d in a.graph.nodes(data=True)])

    with tab_fix:
        st.write("The editor proposes the smallest change that helps. Then the students read the new version.")
        if st.button("🔧 Propose and test fixes"):
            with st.spinner("Editing and re-testing..."):
                st.session_state.edits = editor.improve(a, top_n=3)
                edits = st.session_state.edits
        if edits == []:
            st.info("No paragraph was confusing enough to need a fix.")
        for r in edits or []:
            st.markdown(f"### Paragraph {r['chunk']}")
            c1, c2, c3 = st.columns([2, 1, 2])
            c1.markdown(f'<div class="big" style="color:#b91c1c">{r["before"]}</div><div class="note" '
                        f'style="text-align:center">confusion before</div>', unsafe_allow_html=True)
            c2.markdown('<div class="big">→</div>', unsafe_allow_html=True)
            c3.markdown(f'<div class="big" style="color:#15803d">{r["after"]}</div><div class="note" '
                        f'style="text-align:center">confusion after (improved by {r["gain"]})</div>',
                        unsafe_allow_html=True)
            st.write(r["rationale"])
            old = set(r["original_text"].splitlines())
            added = [ln for ln in r["revised_text"].splitlines() if ln.strip() and ln not in old]
            if added:
                st.markdown("**What was added:**")
                for ln in added:
                    st.markdown(f'<div class="added">{html.escape(ln.lstrip("> "))}</div>', unsafe_allow_html=True)
            with st.expander("See the full before and after text"):
                left, right = st.columns(2)
                left.text_area("Before", r["original_text"], height=220, key=f"o{r['chunk']}")
                right.text_area("After", r["revised_text"], height=220, key=f"r{r['chunk']}")

    with tab_trust:
        st.write("Can we trust the simulated students? These checks ask exactly that.")
        m1, m2 = st.columns(2)
        kpi(m1, "Cheating rate after retries", f"{a.leakage_rate:.0%}",
            "share of readings that used knowledge the student should not have")
        kpi(m2, "Cheating rate on first try", f"{a.first_attempt_leakage_rate:.0%}", "before the checker made them retry")
        rep = audit.audit(a)
        st.markdown("**Fairness check**")
        st.caption("Grounding = share of a student's problems that are explained by what that student really does not know.")
        st.dataframe(rep["summary"])
        st.write(f"Stereotype-word hits: **{len(rep['stereotype_hits'])}**")
        st.download_button("⬇ Download sample for human reviewers (CSV)",
                           audit.annotation_sample(a).to_csv(index=False), "audit_sample.csv")
