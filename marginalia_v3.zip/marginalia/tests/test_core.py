import os
os.environ["MARGINALIA_MOCK"] = "1"   # tests never call the API

import unittest
from pathlib import Path

from marginalia import concepts, leakage, pipeline, scoring
from marginalia.chunker import chunk_text
from marginalia.personas import build_personas
from marginalia.schema import Trace

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample_lecture.md"


class CoreTests(unittest.TestCase):
    def test_chunker_splits_on_headings(self):
        chunks = chunk_text("# A\n\nfoo\n\n# B\n\nbar")
        self.assertEqual(len(chunks), 2)
        self.assertTrue(chunks[1].text.startswith("# B"))

    def test_graph_depth_and_acyclic(self):
        chunks = chunk_text(SAMPLE.read_text())
        pc, req = concepts.extract(chunks)
        g = concepts.build_graph(pc, req)
        self.assertEqual(g.nodes["functions"]["depth"], 0)
        self.assertGreater(g.nodes["chain_rule"]["depth"], g.nodes["derivative"]["depth"])

    def test_personas_partition_knowledge(self):
        chunks = chunk_text(SAMPLE.read_text())
        g = concepts.build_graph(*concepts.extract(chunks))
        for p in build_personas(g):
            self.assertEqual(len(set(p["mastered"]) & set(p["unknown"])), 0)
        control = [p for p in build_personas(g) if p["id"] == "control"][0]
        self.assertEqual(control["unknown"], [])

    def test_leakage_detector(self):
        persona = {"unknown": ["limits"]}
        leaky = Trace(think_aloud="Easy, the limit is just the value it approaches.")
        honest = Trace(think_aloud="I don't know what a limit is.")
        self.assertEqual(leakage.detect(leaky, persona), ["limits"])
        self.assertEqual(leakage.detect(honest, persona), [])
        self.assertEqual(leakage.detect(Trace(concepts_used=["limits"]), persona), ["limits"])

    def test_control_persona_is_least_confused(self):
        a = pipeline.run(SAMPLE.read_text())
        means = a.df.groupby("persona")["confusion"].mean()
        self.assertEqual(means.idxmin(), "control")
        self.assertGreater(means["prereq_gap"], means["control"])

    def test_score_capped(self):
        t = Trace(unknown_terms=["x"] * 50)
        self.assertLessEqual(scoring.confusion_score(t), 10.0)

    def test_editor_reduces_confusion(self):
        from marginalia import editor
        a = pipeline.run(SAMPLE.read_text())
        res = editor.improve(a, top_n=2)
        self.assertTrue(res)
        self.assertTrue(all(r["after"] < r["before"] for r in res))

    def test_audit_runs_and_flags_stereotypes(self):
        from marginalia import audit
        a = pipeline.run(SAMPLE.read_text())
        rep = audit.audit(a)
        self.assertIn("gap_vs_control", rep["summary"].columns)
        self.assertEqual(len(rep["stereotype_hits"]), 0)
        a.traces[0].think_aloud = "Typical lazy student, can't read."
        self.assertGreater(len(audit.audit(a)["stereotype_hits"]), 0)

    def test_long_paragraph_is_split(self):
        text = " ".join(f"Sentence number {i} is here." for i in range(200))
        self.assertGreater(len(chunk_text(text)), 3)

    def test_pdf_loader_roundtrip(self):
        from marginalia import loader
        try:
            from reportlab.pdfgen import canvas
            import pypdf  # noqa: F401
        except ImportError:
            self.skipTest("reportlab/pypdf not installed")
        import io
        buf = io.BytesIO()
        c = canvas.Canvas(buf)
        y = 800
        for line in ["Lecture on limits and derivatives for beginners.",
                     "A function assigns one output to each input value.",
                     "The derivative is the slope of the tangent line at a point.",
                     "We use this idea to compute rates of change in many fields."]:
            c.drawString(50, y, line); y -= 20
        c.save()
        text = loader.load_bytes(buf.getvalue(), "x.pdf")
        self.assertIn("derivative", text)

    def test_plain_english_report(self):
        from marginalia import report
        a = pipeline.run(SAMPLE.read_text())
        f = report.findings(a)
        self.assertEqual(len(f), len(a.chunks))
        self.assertTrue(any(x["advice"] for x in f))
        self.assertTrue(all("plain" in p for p in a.personas))
        page = report.html_report(a)
        self.assertIn("Confusion heatmap", page)
        self.assertIn("Student missing the basics", page)
        self.assertEqual(a.leakage_rate, 0.0)


if __name__ == "__main__":
    unittest.main()
